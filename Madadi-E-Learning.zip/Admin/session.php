<?php 

session_start();
$_SESSION['app_name'] = "Sistem Pengelolaan Kelas";


?>