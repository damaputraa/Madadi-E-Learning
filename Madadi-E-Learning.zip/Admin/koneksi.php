<?php 

$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'madadi-e';

$koneksi = mysqli_connect($host, $user, $pass, $db) or die("Gagal Koneksi Ke Database Bro!");

?>